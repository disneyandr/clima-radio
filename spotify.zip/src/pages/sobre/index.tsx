import styles from './styleSobre.module.scss';
export default function Sobre(){
    return(
        <>
            <h1>Sobre aqui</h1>
        </>
    )
}